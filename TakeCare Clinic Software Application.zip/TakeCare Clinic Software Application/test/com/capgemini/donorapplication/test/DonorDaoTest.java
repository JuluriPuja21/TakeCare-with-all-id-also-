package com.capgemini.donorapplication.test;

import static org.junit.Assert.*;

import java.sql.Date;
import java.time.LocalDate;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDaoImpl;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.service.PatientServiceImpl;
import com.capgemini.tcc.service.IPatientService;

public class DonorDaoTest {

	static PatientDaoImpl dao;
	static PatientBean patient;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new PatientDaoImpl();
		patient= new PatientBean();
	}

	@Test
	public void testAddDonarDetails() throws PatientException {

		assertNotNull(dao.addPatientDetails(patient));

	}

	/************************************
	 * Test case for addDonarDetails()
	 * 
	 ************************************/

	@Ignore
	@Test
	public void testAddDonarDetails1() throws PatientException {
		// increment the number next time you test for positive test case
		assertEquals(1001, dao.addPatientDetails(patient));
	}

	/************************************
	 * Test case for addDonarDetails()
	 * 
	 ************************************/

	@Test
	public void testAddDonarDetails2() throws PatientException {

		patient.setpatient_name("Shashwathi");
		patient.setage(50);
		patient.setphone("9876543210");
		patient.setdescription("whitefield");
	
		assertTrue("Data Inserted successfully",
				Integer.parseInt(dao.addPatientDetails(patient)) > 1000);

	}

	/********************************************
	 * Test case for retriveAllDetails()
	 ************************************************/
	@Test
	public void testViewAll() throws PatientException {
		assertNotNull(dao.retriveAllDetails());
	}

	/****************************************************
	 * Test case for viewById()
	 ******************************************************/

	@Test
	public void testById() throws PatientException {
		assertNotNull(dao.viewPatientDetails("1026"));
	}

	@Ignore
	@Test
	public void testById1() throws PatientException {
		assertEquals("TestName", dao.viewPatientDetails("1010").getpatient_name());
	}

}
