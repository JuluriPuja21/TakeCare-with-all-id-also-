package com.capgemini.tcc.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.util.DBConnection;


public class PatientDaoImpl implements IPatientDAO 
{
	
	Logger logger=Logger.getRootLogger();
	public PatientDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	

	//------------------------ 1. Donor Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addDonorDetails(PatientBean donor)
	 - Input Parameters	:	PatientBean donor
	 - Return Type		:	String
	 - Throws			:  	PatientException
	 - Author			:	PUJA
	 - Creation Date	:	3/11/2018
	 - description		:	Adding Donor
	 ********************************************************************************************************/

	public String addPatientDetails(PatientBean patient) throws PatientException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String donorId=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,patient.getpatient_name());	
			preparedStatement.setDouble(2,patient.getage());	
			preparedStatement.setString(3,patient.getphone());
			preparedStatement.setString(4,patient.getdescription());
						
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.PATIENTID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				donorId=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new PatientException("Inserting donor details failed ");

			}
			else
			{
				logger.info("Donor details added successfully:");
				return donorId;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new PatientException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new PatientException("Error in closing db connection");

			}
		}
		
		
	}

	//------------------------ 1. Donor Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	viewDonorDetails(String donorId)
	 - Input Parameters	:	donorId
	 - Return Type		:	PatientBean
	 - Throws			:  	PatientException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	18/11/2016
	 - description		:	ViewDonorDetails
	 ********************************************************************************************************/
	public PatientBean viewPatientDetails(String donorId) throws PatientException {
		
		Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		PatientBean bean=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_PATIENT_DETAILS_QUERY);
			preparedStatement.setString(1,donorId);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				bean = new PatientBean();
				bean.setpatient_name(resultset.getString(1));
				bean.setage(resultset.getInt(2));
				bean.setphone(resultset.getString(3));
				bean.setdescription(resultset.getString(4));
				bean.setconsultation_date(resultset.getDate(5));
				
				
			}
			
			if( bean != null)
			{
				logger.info("Record Found Successfully");
				return bean;
			}
			else
			{
				logger.info("Record Not Found Successfully");
				return null;
			}
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new PatientException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new PatientException("Error in closing db connection");

			}
		}
		
	}

	//------------------------ 1. Donor Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	retriveAllDetails()
	 - Input Parameters	:	
	 - Return Type		:	List
	 - Throws		    :  	PatientException
	 - Author	     	:	CAPGEMINI
	 - Creation Date	:	18/11/2016
	 - description		:	return list
	 ********************************************************************************************************/

	public List<PatientBean> retriveAllDetails() throws PatientException {
		
		Connection con=DBConnection.getInstance().getConnection();
		int donorCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<PatientBean> donorList=new ArrayList<PatientBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				PatientBean bean=new PatientBean();
				bean.setpatient_name(resultset.getString(1));
				bean.setage(resultset.getInt(2));
				bean.setphone(resultset.getString(3));
				bean.setdescription(resultset.getString(4));
				bean.setconsultation_date(resultset.getDate(5));
				donorList.add(bean);
				
				donorCount++;
			}			
			
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new PatientException("Tehnical problem occured. Refer log");
		}
		
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new PatientException("Error in closing db connection");

			}
		}
		
		if( donorCount == 0)
			return null;
		else
			return donorList;
	}

}
