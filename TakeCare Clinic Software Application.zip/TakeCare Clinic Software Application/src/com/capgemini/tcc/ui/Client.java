package com.capgemini.tcc.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.service.PatientServiceImpl;
import com.capgemini.tcc.service.IPatientService;

public class Client {

	static Scanner sc = new Scanner(System.in);
	static IPatientService patientService = null;
	static PatientServiceImpl patientServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		PatientBean patientBean = null;

		String patientId = null;
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("TAKECARE CLINIC SOFTWARE APPLICATION ");
			System.out.println("_______________________________\n");

			System.out.println("1.Add patient ");
			System.out.println("2.View patient");
			System.out.println("3.Retrive All");
			System.out.println("4.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (patientBean == null) {
						patientBean = populateDonorBean();
						// System.out.println(donorBean);
					}

					try {
						patientService = new PatientServiceImpl();
						patientId = patientService.addPatientDetails(patientBean);

						System.out
								.println("patient details  has been successfully registered ");
						System.out.println("patient  ID Is: " + patientId);

					} catch (PatientException PatientException) {
						logger.error("exception occured", PatientException);
						System.out.println("ERROR : "
								+ PatientException.getMessage());
					} finally {
						patientId = null;
						patientService = null;
						patientBean = null;
					}

					break;

				case 2:

					patientServiceImpl = new PatientServiceImpl();

					System.out.println("Enter numeric donor id:");
					patientId = sc.next();

					while (true) {
						if (patientServiceImpl.validateDonorId(patientId)) {
							break;
						} else {
							System.err
									.println("Please enter numeric PATIENT id only, try again");
							patientId = sc.next();
						}
					}

					patientBean = getDonorDetails(patientId);

					if (patientBean != null) {
						System.out.println("Name             :"
								+ patientBean.getpatient_name());
						System.out.println("AGE  :"
								+ patientBean.getage());
						System.out.println("Phone Number     :"
								+ patientBean.getphone());
						
						System.out.println("DESCRIPTION        :"
								+ patientBean.getdescription());
	
						System.out.println("CONSULTATION DATE       :"
								+ patientBean.getconsultation_date());
						
					} else {
						System.err
								.println("There are no PATIENT details associated with patient id "
										+ patientId);
					}

					break;

				case 3:

					patientService = new PatientServiceImpl();
					try {
						List<PatientBean> donorList = new ArrayList<PatientBean>();
						donorList = patientService.retriveAll();

						if (donorList != null) {
							Iterator<PatientBean> i = donorList.iterator();
							while (i.hasNext()) {
								System.out.println(i.next());
							}
						} else {
							System.out
									.println("Nobody has made a donation, yet.");
						}

					}

					catch (PatientException e) {

						System.out.println("Error  :" + e.getMessage());
					}

					break;

				case 4:

					System.out.print("Exit Trust Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
	}// end of try

	/*
	 * This function will call the service layer method and return the bean
	 * object which is populated by the information of the given patientId in
	 * parameter
	 */
	private static PatientBean getDonorDetails(String patientId) {
		PatientBean patientBean = null;
		patientService = new PatientServiceImpl();

		try {
			patientBean = patientService.viewPatientDetails(patientId);
		} catch (PatientException patientException) {
			logger.error("exception occured ", patientException);
			System.out.println("ERROR : " + patientException.getMessage());
		}

		patientService = null;
		return patientBean;
	}

	/*
	 * This function will be called by main and will return a validated bean
	 * object OR null if details are invalid
	 */
	private static PatientBean populateDonorBean() {

		// Reading and setting the values for the donorBean
		
		PatientBean patientBean = new PatientBean();;

		System.out.println("\n Enter Details");

		System.out.println("Enter patient name: ");
		patientBean.setpatient_name(sc.next());
		
		System.out.println("Enter patient age: ");

		try {
			patientBean.setage(sc.nextInt());
		} catch (InputMismatchException inputMismatchException) {
			sc.nextLine();
			System.err
					.println("Please enter a numeric value for age, try again");
			}

		System.out.println("Enter patient phone number: ");
		patientBean.setphone(sc.next());

		System.out.println("Enter description: ");
		patientBean.setdescription(sc.next());

		
		patientServiceImpl = new PatientServiceImpl();

		try {
			patientServiceImpl.validateDonor(patientBean);
			return patientBean;
		} catch (PatientException PatientException) {
			logger.error("exception occured", PatientException);
			System.err.println("Invalid data:");
			System.err.println(PatientException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}
