package com.capgemini.tcc.bean;

import java.util.Date;


public class PatientBean{
	private String Patient_id;
	private String patient_name;
	private String phone;
	private String description;
	private int age;
	private Date consultation_date;
	
	public String getPatient_id() {
		return Patient_id;
	}
	public void setPatient_id(String Patient_id) {
		this.Patient_id = Patient_id;
	}
	public String getpatient_name() {
		return patient_name;
	}
	public void setpatient_name(String patient_name) {
		this.patient_name = patient_name;
	}
	public String getphone() {
		return phone;
	}
	public void setphone(String phone) {
		this.phone = phone;
	}
	public String getdescription() {
		return description;
	}
	public void setdescription(String description) {
		this.description = description;
	}
	public int getage() {
		return age;
	}
	public void setage(int age) {
		this.age = age;
	}
	public Date getconsultation_date() {
		return consultation_date;
	}
	public void setconsultation_date(Date consultation_date) {
		this.consultation_date = consultation_date;
	}
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Printing Patient Details \n");
		sb.append("patient Name: " +patient_name +"\n");
		sb.append("Donation Amount: "+ age +"\n");
		sb.append("Phone Number: "+ phone +"\n");
		sb.append("patient description: "+ description +"\n");
	    sb.append("consultation  Date: "+ consultation_date);
		return sb.toString();
	}
	

	
}
